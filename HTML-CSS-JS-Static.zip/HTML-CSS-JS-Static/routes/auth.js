import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import Joi from "joi";

const router = express.Router();

const regSchema = Joi.object({
  username: Joi.string().required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  age: Joi.number().required()
});

router.post("/register", async (req, res) => {
  const { error } = regSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.message });

  const { username, email, password, age } = req.body;

  if (age < 18) return res.status(403).json({ error: "Must be 18+." });

  const exist = await User.findOne({ email });
  if (exist) return res.status(400).json({ error: "Email already used." });

  const passwordHash = await bcrypt.hash(password, 10);

  const user = await User.create({
    username,
    email,
    passwordHash,
    age
  });

  return res.json({ success: true });
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  const user = await User.findOne({ username });
  if (!user) return res.status(400).json({ error: "User not found." });

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(400).json({ error: "Wrong password." });

  const token = jwt.sign(
    { id: user._id, isAdmin: user.isAdmin },
    process.env.JWT_SECRET,
    { expiresIn: "7d" }
  );

  res.cookie("token", token, { httpOnly: true });
  res.json({ success: true });
});

export default router;