import express from "express";
import { ensureAuth } from "../middleware/auth.js";
import User from "../models/User.js";
import crypto from "crypto";

const router = express.Router();

router.post("/dice", ensureAuth, async (req, res) => {
  let { bet, chance } = req.body;
  bet = Math.round(bet * 100);

  if (bet <= 0) return res.status(400).json({ error: "Invalid bet" });

  const user = req.user;

  if (user.balance < bet) return res.status(400).json({ error: "Low balance" });

  await User.findByIdAndUpdate(user._id, { $inc: { balance: -bet } });

  const roll = crypto.randomInt(0, 10000);
  const win = roll < chance * 100;

  let payout = 0;
  if (win) {
    const mult = 100 / chance * 0.98;
    payout = Math.floor(bet * mult);
    await User.findByIdAndUpdate(user._id, { $inc: { balance: payout } });
  }

  const updatedUser = await User.findById(user._id);

  res.json({
    result: win ? "win" : "lose",
    newBalance: updatedUser.balance / 100,
    payout: payout / 100
  });
});

export default router;