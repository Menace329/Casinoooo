import express from "express";
import { ensureAuth } from "../middleware/auth.js";
import User from "../models/User.js";

const router = express.Router();

router.post("/mines", ensureAuth, async (req, res) => {
  let { bet } = req.body;
  bet = Math.round(bet * 100);

  if (bet <= 0) return res.json({ error: "Invalid bet" });

  const user = req.user;

  if (user.balance < bet) return res.json({ error: "Low balance" });

  await User.findByIdAndUpdate(user._id, { $inc: { balance: -bet } });

  // Simple 50/50 mines logic
  const win = Math.random() < 0.5;
  let payout = 0;

  if (win) {
    payout = Math.floor(bet * 1.5);
    await User.findByIdAndUpdate(user._id, { $inc: { balance: payout } });
  }

  const updated = await User.findById(user._id);

  res.json({
    result: win ? "win" : "lose",
    payout: payout / 100,
    newBalance: updated.balance / 100
  });
});

export default router;