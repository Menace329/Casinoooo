async function playDice() {
  const bet = 1.00;
  const chance = 49;

  const res = await fetch("/api/game/dice", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ bet, chance })
  });

  const data = await res.json();

  document.getElementById("result").innerText = JSON.stringify(data);
}