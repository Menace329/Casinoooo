async function playMines() {
  const bet = 1.00;

  const res = await fetch("/api/game/mines", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ bet })
  });

  const data = await res.json();

  document.getElementById("result").innerText = JSON.stringify(data);
}